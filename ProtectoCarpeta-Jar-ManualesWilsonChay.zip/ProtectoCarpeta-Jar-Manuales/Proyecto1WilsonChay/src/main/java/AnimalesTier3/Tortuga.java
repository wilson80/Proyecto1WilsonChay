/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier3;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Tortuga extends Mascotas{
    public Tortuga() {
        setNombreMascota("Tortuga");
        setUnidadesDeDanoInicial(1);
        setUnidadesDeVidaInicial(2);
        setTipos("reptil");
        setTier(3);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }
}
//20. Tortuga [1/2]
//○ Protección aliada: Dar 1/2/3 amigos detrás de Melón Armor al morir.
//○ Tipo reptil