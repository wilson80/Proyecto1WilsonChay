/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier1;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class CasillaVacia extends Mascotas{

    public CasillaVacia() {
        setNombreMascota("vacio");
        setPosicion(0);
        setUnidadesDeDanoInicial(0);
        setUnidadesDeDanoInicial(0);
        setNivel(0);
        setExperiencia(0);
        setTipos("solitario");
    }
    
}
