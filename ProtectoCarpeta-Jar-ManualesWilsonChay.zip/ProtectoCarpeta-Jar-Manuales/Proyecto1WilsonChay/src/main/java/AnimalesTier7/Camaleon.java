/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier7;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Camaleon extends Mascotas{
    public Camaleon() {
        setNombreMascota("Camal..");
        setUnidadesDeDanoInicial(8);
        setUnidadesDeVidaInicial(8);
        setTipos("reptil,solitario");
        setTier(7);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }
}
//54. Camaleón [8/8]
//○ Habilidades por nivel
//■ (1) Copia la vida del enemigo más fuerte
//■ (2) Copia la vida y el daño del enemigo más fuerte
//■ (3) Copia la vida, el daño y la habilidad del enemigo más fuerte
//○ Tipo: Reptil/Solitario