/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnimalesTier5;

import Tienda.Mascotas;

/**
 *
 * @author Jonwil
 */
public class Mono extends  Mascotas{
    public Mono() {
        setNombreMascota("Mono   ");
        setUnidadesDeDanoInicial(1);
        setUnidadesDeVidaInicial(2);
        setTipos("mamifero");
        setTier(5);
        setDescripcionHabilidad("vacio");
        setNivel(1);
        setExperiencia(1);

    }
}
//40. Mono: [1/2]
//Turno final:
//○ Amistad: Dar al amigo más a la derecha (+2/+3)/ (+4/+6) / (+6/+9) .
//○ Tipo: Mamífero