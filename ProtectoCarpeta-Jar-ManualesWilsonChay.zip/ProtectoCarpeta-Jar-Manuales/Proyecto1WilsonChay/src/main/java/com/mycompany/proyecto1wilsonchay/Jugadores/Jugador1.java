package com.mycompany.proyecto1wilsonchay.Jugadores;

import AnimalesTier1.CasillaVacia;
import Tienda.Mascotas;
import Tienda.Tienda;
import java.util.Scanner;

/**
 *
 * @author Jonwil
 */
public class Jugador1 extends Jugadores{
    
    public Jugador1() {
    }
    
    
    
        
}
